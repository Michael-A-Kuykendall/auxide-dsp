# Developer Certificate of Origin (DCO)

By contributing to this project, you certify that:

1. The contribution is your original work, or you have the right to submit it under the project license.
2. You understand and agree that the contribution is licensed under the MIT License.
3. You have the authority to submit the work and, if applicable, to bind your employer.
