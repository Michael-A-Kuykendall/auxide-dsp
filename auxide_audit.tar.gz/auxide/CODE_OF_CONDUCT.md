# Code of Conduct

We are committed to providing a respectful, harassment-free experience for everyone.

- Be respectful and considerate.
- No harassment, discrimination, or personal attacks.
- Assume good faith; disagree constructively.

If you experience or witness unacceptable behavior, email the maintainer at michaelallenkuykendall@gmail.com.

The maintainer may take any action deemed appropriate, including moderation of issues and pull requests.
