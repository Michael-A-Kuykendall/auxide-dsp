# Sponsors

Thank you to our amazing sponsors who make Auxide possible! 🙏

## Current Sponsors

*None yet — be the first!*

## Sponsorship Tiers

- **$5/month**: Coffee tier ☕ - Eternal gratitude + sponsor badge
- **$25/month**: Bug prioritizer 🐛 - Priority support + name in SPONSORS.md
- **$100/month**: Corporate backer 🏢 - Logo placement + monthly office hours
- **$500/month**: Infrastructure partner 🚀 - Direct support + roadmap input

[Become a sponsor](https://github.com/sponsors/Michael-A-Kuykendall)