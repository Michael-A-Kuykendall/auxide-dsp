# Security Policy

- Please report vulnerabilities privately to michaelallenkuykendall@gmail.com.
- Do not open public issues for suspected vulnerabilities.
- There is no formal embargo process; coordinated disclosure will be handled case-by-case with the maintainer.
